@extends('admin-layout.main_no_sidebar')
@section('title', 'Hbd')
@section('subtitle', 'Hbd')

@section('content')



<style>
  .bd-placeholder-img {
    font-size: 1.125rem;
    text-anchor: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    user-select: none;
  }

  @media (min-width: 768px) {
    .bd-placeholder-img-lg {
      font-size: 3.5rem;
    }
  }

  .b-example-divider {
    width: 100%;
    height: 3rem;
    background-color: rgba(0, 0, 0, .1);
    border: solid rgba(0, 0, 0, .15);
    border-width: 1px 0;
    box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
  }

  .b-example-vr {
    flex-shrink: 0;
    width: 1.5rem;
    height: 100vh;
  }

  .bi {
    vertical-align: -.125em;
    fill: currentColor;
  }

  .nav-scroller {
    position: relative;
    z-index: 2;
    height: 2.75rem;
    overflow-y: hidden;
  }

  .nav-scroller .nav {
    display: flex;
    flex-wrap: nowrap;
    padding-bottom: 1rem;
    margin-top: -1px;
    overflow-x: auto;
    text-align: center;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
  }

  .btn-bd-primary {
    --bd-violet-bg: #712cf9;
    --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

    --bs-btn-font-weight: 600;
    --bs-btn-color: var(--bs-white);
    --bs-btn-bg: var(--bd-violet-bg);
    --bs-btn-border-color: var(--bd-violet-bg);
    --bs-btn-hover-color: var(--bs-white);
    --bs-btn-hover-bg: #6528e0;
    --bs-btn-hover-border-color: #6528e0;
    --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
    --bs-btn-active-color: var(--bs-btn-hover-color);
    --bs-btn-active-bg: #5a23c8;
    --bs-btn-active-border-color: #5a23c8;
  }

  .bd-mode-toggle {
    z-index: 1500;
  }
</style>
<link href="{{ url('assets_admin/css/list-group.css') }}" rel="stylesheet">

<div class="container py-3">
  <header>
    <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
      <a href="/" class="d-flex align-items-center link-body-emphasis text-decoration-none">
        {{-- <svg xmlns="http://www.w3.org/2000/svg" width="40" height="32" class="me-2" viewBox="0 0 118 94"
          role="img">

          <path fill-rule="evenodd" clip-rule="evenodd"
            d="M24.509 0c-6.733 0-11.715 5.893-11.492 12.284.214 6.14-.064 14.092-2.066 20.577C8.943 39.365 5.547 43.485 0 44.014v5.972c5.547.529 8.943 4.649 10.951 11.153 2.002 6.485 2.28 14.437 2.066 20.577C12.794 88.106 17.776 94 24.51 94H93.5c6.733 0 11.714-5.893 11.491-12.284-.214-6.14.064-14.092 2.066-20.577 2.009-6.504 5.396-10.624 10.943-11.153v-5.972c-5.547-.529-8.934-4.649-10.943-11.153-2.002-6.484-2.28-14.437-2.066-20.577C105.214 5.894 100.233 0 93.5 0H24.508zM80 57.863C80 66.663 73.436 72 62.543 72H44a2 2 0 01-2-2V24a2 2 0 012-2h18.437c9.083 0 15.044 4.92 15.044 12.474 0 5.302-4.01 10.049-9.119 10.88v.277C75.317 46.394 80 51.21 80 57.863zM60.521 28.34H49.948v14.934h8.905c6.884 0 10.68-2.772 10.68-7.727 0-4.643-3.264-7.207-9.012-7.207zM49.948 49.2v16.458H60.91c7.167 0 10.964-2.876 10.964-8.281 0-5.406-3.903-8.178-11.425-8.178H49.948z"
            fill="currentColor"></path>
        </svg> --}}
        {{-- <span class="fs-4">Pricing example</span> --}}
      </a>

      <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="{{ route('absence.pt')}}">absen</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="{{ route('birthday.pt') }}">list</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="#">lorem</a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="#">lorem</a>
      </nav>
    </div>

    {{-- <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
      <h1 class="display-4 fw-normal">Pricing</h1>
      <p class="fs-5 text-body-secondary">Quickly build an effective pricing table for your potential customers
        with this Bootstrap example. It’s built with default Bootstrap components and utilities with little
        customization.</p>
    </div> --}}
  </header>

  <main class="container">
    {{-- <div class="d-flex align-items-center p-3 my-3 text-white bg-purple rounded shadow-sm">
      <img class="me-3" src="/docs/5.3/assets/brand/bootstrap-logo-white.svg" alt="" width="48" height="38">
      <div class="lh-1">
        <h1 class="h6 mb-0 text-white lh-1">Bootstrap</h1>
        <small>Since 2011</small>
      </div>
    </div> --}}
    <div class="my-3 p-3 bg-body rounded shadow-sm">
      <h6 class="border-bottom pb-2 mb-0">BoD Periode {{ $from_sunday_date.' '.$from_month_id .' to '. $to_sunday_date.'
        '.$to_month_id_sunday }}</h6>

      @foreach($cekHbd as $row)
      <div class="d-flex text-body-secondary pt-3">
        <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" role="img"
          aria-label="Placeholder: 32x32" focusable="false">
          <title>Placeholder</title>
          <rect width="100%" height="100%" fill="#c0c0c0" /><text x="50%" y="50%" fill="#c0c0c0" dy=".3em">32x32</text>
        </svg>
        @if(explode('-', $row->tgl_lahir)[2] == explode('-', $dt)[2])
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100 bg-success bg-opacity-25">
          @else
          <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
            @endif
            <div class="d-flex justify-content-between">
              <strong class="text-gray-dark">{{ $row->nama_lengkap }}</strong>
              {{-- <a href="#">Follow</a> --}}
            </div>
            @php $tgl = \Carbon\Carbon::parse($row->tgl_lahir); @endphp
            <span class="d-block">{{ $tgl->isoFormat('DD MMMM Y') }}</span>
          </div>
        </div>
        @endforeach



        {{-- <small class="d-block text-end mt-3">
          <a href="#">All suggestions</a>
        </small> --}}
      </div>
  </main>


  <script src="{{ url('assets_admin/js/bootstrap-5.bundle.min.js') }}"></script>


  @endsection