<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DependantController;
use App\Http\Controllers\PelkatAbsenceController;
use App\Http\Controllers\pt\PtHomeController;
use App\Http\Controllers\pt\PtJematController;
use App\Http\Controllers\user\UploadController;
use App\Http\Controllers\user\ProfileController;
use App\Http\Controllers\pka\PkaProgramController;
use App\Http\Controllers\sysadmin\JematController;
use App\Http\Controllers\sysadmin\AbsenceController;
use App\Http\Controllers\sysadmin\DocumentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/website', function () {
    return view('template_web.index');
});

Route::get('/', function () {
    return view('welcome');
});

Route::get('/test', function () {
    return view('test');
});

Route::get('/ourteam', function () {
    return view('our_team');
});

Route::get('/contact', function () {
    return view('contact');
});

Auth::routes();

Route::get('home', [HomeController::class, 'index'])->name('home');

// absence
Route::get('absensi-pt', [PelkatAbsenceController::class, 'absensiPt'])->name('absence.pt');
Route::get('absensi-pa', [PelkatAbsenceController::class, 'absensiPa'])->name('absence.pa');
Route::post('absensi', [PelkatAbsenceController::class, 'store'])->name('absence.pelkat');

#Route::get('upload/create', [UploadController::class, 'create'])->name('user.upload.create');
#Route::post('upload/store', [UploadController::class, 'store'])->name('user.upload.store');
#Route::delete('upload/delete', [UploadController::class, 'delete'])->name('user.upload.delete');


Route::get('changePassword', [ChangePasswordController::class, 'index'])->name('changePassword');
Route::post('changePassword', [ChangePasswordController::class, 'changePassword']);
Route::get('changePasswordExp', [ChangePasswordController::class, 'show'])->name('changePasswordExp');
Route::post('changePasswordExp', [ChangePasswordController::class, 'changePasswordExp']);

Route::prefix('Jemat')->group(function () {
    Route::group(['middleware' => 'is.jemat'], function () {
        ########## ==PARAM DATE= ##########
        Route::get('home', [HomeController::class, 'handleJemat'])->name('jemat.route');
        Route::patch('home/{id}', [HomeController::class, 'updateJemat'])->name('jemat.update');

        Route::get('upload', [UploadController::class, 'create'])->name('jemat.upload.create');
        Route::post('upload', [UploadController::class, 'store'])->name('jemat.upload.store');
        Route::delete('upload', [UploadController::class, 'delete'])->name('jemat.upload.delete');
        Route::get('profile', [ProfileController::class, 'index'])->name('jemat.profile');
        Route::get('profile/download/{temporaryfile}', [ProfileController::class, 'getDownload']);
        Route::get('profile/{jemat:nama_keluarga}', [HomeController::class, 'editAlamat']); 
        Route::patch('profile/{id}', [HomeController::class, 'updateAlamat'])->name('jemat.update.alamat');
        Route::post('profile/uploadPhoto', [ProfileController::class, 'updatePhoto'])->name('jemat.update.photo'); 
        
        Route::get('getDistricts/{id}', [DependantController::class, 'getDistricts']);
        Route::get('getVillages/{id}', [DependantController::class, 'getVillages']);


        // PKA ANGGARAN
        Route::get('PKA/', [PkaProgramController::class, 'index'])->name('pka.index');
        Route::get('PKA/create', [PkaProgramController::class, 'create'])->name('pka.create');
        Route::post('PKA/create', [PkaProgramController::class, 'store'])->name('pka.store');
    });
});

########## PT TERUNA ##########
Route::prefix('PT')->group(function () {
    Route::group(['middleware' => 'is.teruna'], function () {
        Route::get('home', [PtHomeController::class, 'index'])->name('pt.route');
        Route::get('absensi', [PtHomeController::class, 'index'])->name('pt.route');
        Route::get('teruna', [PtJematController::class, 'teruna'])->name('pt.teruna');
        Route::get('pengurus-pelayan', [PtJematController::class, 'pelayanPengurusTeruna'])->name('pt.pengurus');
        #Route::post('pengurus-pelayan', [PtJematController::class, 'pelayan'])->name('pt.pengurus.post');
    });
});        

Route::prefix('Admin')->group(function () {
    Route::group(['middleware' => 'is.admin'], function () {
        ########## ==PARAM DATE= ##########
        Route::get('home', [HomeController::class, 'handleAdmin'])->name('admin.route');
        Route::get('absence', [AbsenceController::class, 'create'])->name('admin.absence.create');
        Route::post('absence', [AbsenceController::class, 'store'])->name('admin.absence.store');
        
    Route::get('/ajax',[JematController::class,'indexAjax']);
    Route::post('/ajax/search',[JematController::class,'showAJax'])->name('ajax.search');
        
        Route::get('jemaat', [JematController::class, 'index'])->name('admin.jemat');
        Route::get('jemaat/edit/{id}', [JematController::class, 'edit'])->name('admin.jemat.edit');
        Route::patch('jemaat/edit/{id}', [JematController::class, 'update'])->name('admin.jemat.update');
        Route::get('jemaat/scheduleHbd', [JematController::class, 'cekHbd'])->name('admin.jemat.hbd');
        #Route::get('jemaat/scheduleHbd/search', [JematController::class, 'searchCekHbd'])->name('admin.jemat.searchHbd');
        Route::get('jemaat/scheduleHbd/searching', [JematController::class, 'getSearchCekHbd'])->name('admin.jemat.getSearchHbd');
    
        // LAMPIRAN - LAMPIRAN
        Route::get('lampiran', [DocumentController::class, 'index'])->name('admin.lampiran');
        Route::get('lampiran/upload', [DocumentController::class, 'create'])->name('admin.lampiran.upload.create');
        Route::post('lampiran/upload', [DocumentController::class, 'store'])->name('admin.lampiran.upload.store');
        Route::delete('lampiran/upload', [DocumentController::class, 'delete'])->name('admin.lampiran.upload.delete');
        Route::get('lampiran/download/{temporaryfile}', [DocumentController::class, 'getDownload']);

        // absensi
        Route::get('absensi/pa', [PelkatAbsenceController::class, 'searchAbsencePa'])->name('absence.search.pa');
        Route::get('absensi/pt', [PelkatAbsenceController::class, 'searchAbsencePt'])->name('absence.search.pt');

    });
});
