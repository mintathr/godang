@extends('admin-layout.main_no_sidebar')
@section('title', 'IHMPT')
@section('subtitle', 'IHMPT')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Form IHMPT</h3>
            </div>
            <form role="form" method="POST" action="{{ route('admin.absence.store') }}">
                @method('post')
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            @foreach($pt_pengurus as $ptPengurus)
                            <div class="col-md-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="$ptPengurus['nama_pengurus']" value="Personal" />
                                        {{ $ptPengurus['nama_pengurus'] }} 
                                    </label>
                                </div>
                            </div>
                            @endforeach
                            @foreach($pt_pelayan as $ptPelayan)
                            <div class="col-md-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="$ptPengurus['nama_pengurus']" value="Personal" />
                                        {{ $ptPelayan['nama_pelayan'] }} 
                                    </label>
                                </div>
                            </div>
                            @endforeach
                            @foreach($pt_eka as $ptEka)
                            <div class="col-md-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="apt[]" value="{{ $ptEka->id.' - '.$ptEka->nama_lengkap }}" />
                                        {{ $ptEka->nama_lengkap }} 
                                    </label>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>

                        <label>NIK Pengurus</label>
                        <select name="nik" class="form-control select2bs4 @error('nik') is-invalid @enderror"
                            style="width: 100%;">
                            <option selected disabled>== Pilih Karyawan ==</option>
                            @foreach ($pt_pengurus as $rowPengurus)
                            <option value="{{ $rowPengurus['nik_pengurus'].'/dwi' }}">{{ $rowPengurus['nama_pengurus']
                                }}</option>
                            @endforeach
                        </select>
                        @error('nik')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>NIK DWI</label>
                        <select name="nik" class="form-control select2bs4 @error('nik') is-invalid @enderror"
                            style="width: 100%;">
                            <option selected disabled>== Pilih Karyawan ==</option>
                            @foreach ($pt_pelayan as $rowPelayan)
                            <option value="{{ $rowPelayan['nik_pelayan'].'/dwi' }}">{{ $rowPelayan['nama_pelayan'] }}
                            </option>
                            @endforeach
                        </select>
                        @error('nik')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>NIK Eka</label>
                        <select name="nik" class="form-control select2bs4 @error('nik') is-invalid @enderror"
                            style="width: 100%;">
                            <option selected disabled>== Pilih Karyawan ==</option>
                            @foreach ($pt_pelayan as $rowPelayan)
                            <option value="{{ $rowPelayan['nik_pelayan'].'/dwi' }}">{{ $rowPelayan['nama_pelayan'] }}
                            </option>
                            @endforeach
                        </select>
                        @error('nik')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Tanggal</label>
                        <input type="text" name="tanggal_pencarian" class="form-control date float"
                            value="{{ old('tanggal_pencarian') }}" placeholder="Input Tanggal">
                        @error('nik')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input type="radio" name="survey_time" class="custom-control-input" value="11.00 - 12.00"
                                id="survey_time3" />
                            <label for="survey_time3" class="custom-control-label">11.00 - 12.00</label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="btn-group btn-group-toggle btn-block mb-5" data-toggle="buttons">
                            <label class="btn btn-lg btn-outline-info">
                                <input type="radio" name="tipe_klien" autocomplete="off" v-on:click="personal = true"
                                    v-model="fields.tipe_klien" value="Personal" />
                                Personal
                            </label>

                            <label class="btn btn-lg btn-outline-info">
                                <input type="radio" name="tipe_klien" autocomplete="off" v-on:click="personal = false"
                                    v-model="fields.tipe_klien" value="Bisnis" />Bisnis
                            </label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4">
                            <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                <label class="btn btn-lg btn-outline-info">
                                    <input type="checkbox" name="tipe_klien" value="Personal" />
                                    Personal
                                </label>
                            </div>
                        </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="tipe_klien" value="Personal" />
                                        Paersonal
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="tipe_klien" value="Personal" />
                                        Paersonal Paersonal Paersonal
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="btn-group btn-group-toggle btn-block mb-2" data-toggle="buttons">
                                    <label class="btn btn-lg btn-outline-info">
                                        <input type="checkbox" name="tipe_klien" value="Personal" />
                                        Paersonal
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="form-group">
                            <div class="btn-group btn-group-toggle btn-block mb-5" data-toggle="buttons">
                                <label class="btn btn-lg btn-outline-info">
                                    <input type="checkbox" name="tipe_klien" autocomplete="off"
                                        v-on:click="personal = true" v-model="fields.tipe_klien" value="Personal" />
                                    Personal
                                </label>

                                <label class="btn btn-lg btn-outline-info">
                                    <input type="checkbox" name="tipe_klien" autocomplete="off"
                                        v-on:click="personal = false" v-model="fields.tipe_klien"
                                        value="Bisnis" />Bisnis
                                </label>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        {{-- <button onclick="window.location.href='{{ route(" user") }}';" type="button"
                            class="btn btn-default float-right">Back</button> --}}
                    </div>
            </form>
        </div>
    </div>
</div>
@push('script-select2')
<script>
    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })

    })
</script>
@endpush
@endsection