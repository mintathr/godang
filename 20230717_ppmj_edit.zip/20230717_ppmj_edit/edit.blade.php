@extends('ppmj_documentation.main_dokumentasi')
@section('title', 'Edit Documentation SCS')
@section('subtitle', 'Edit Documentation SCS')

@section('content_dokumentasi')
<script src="{{ url('assets_documentation/js/jquery.slim.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Pasal {{ $id->pasal }}</h4>
          <button onclick="window.location.href='{{ route("ppmj") }}'" type="button" class="close" data-bs-dismiss="modal">&times;</button>
        </div>
        
        <div class="modal-body">
            <form role="form" method="POST" action="{{ route('ppmj.update', $id->id) }}">
                    @method('patch')
                    @csrf
                <div class="mb-3">
                  <textarea class="form-control" name="keterangan" rows="7" cols="50" style="min-width: 100%">
                    {{ $id->keterangan }}
                  </textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </form>
        </div>
        
        {{-- <div class="modal-footer">
        </div> --}}
        
      </div>
    </div>
  </div>


    <script type="text/javascript">
        $(window).on('load', function() {
            $('#myModal').modal({backdrop: 'static', keyboard: false});  
            $('#myModal').modal('show');
        });
    </script>
@endsection